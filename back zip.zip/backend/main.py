from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uuid

app = FastAPI(title="Team Tracking API")

# 🚨 CRITICAL: Enable CORS so your React app (running on localhost:5173) 
# is allowed to fetch data from your Python server (running on localhost:8000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], # React's default ports
    allow_credentials=True,
    allow_methods=["*"], # Allows GET, POST, PUT, DELETE
    allow_headers=["*"],
)

# 📋 In-Memory Database Placeholders (Temporary arrays)
employees_db = [
    {"id": "EMP-101", "name": "Sarah Connor", "avatar": "👩‍💻"},
    {"id": "EMP-102", "name": "Alex Mercer", "avatar": "👨‍💻"},
    {"id": "EMP-103", "name": "Elena Rostova", "avatar": "👩‍🔬"},
]

tasks_db = [
    {"id": "1", "title": "Setup Project Repository", "description": "Initialize git, configure eslint.", "status": "todo", "assignedTo": "EMP-101"},
]

# 📐 Data Models (Validation schemas)
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    status: str
    assignedTo: str

class TaskUpdate(BaseModel):
    status: str

class EmployeeCreate(BaseModel):
    id: str
    name: str
    avatar: str

# 📡 EMPLOYEES ENDPOINTS

@app.get("/api/employees")
def get_employees():
    return employees_db

@app.post("/api/employees")
def create_employee(employee: EmployeeCreate):
    new_emp = employee.dict()
    employees_db.append(new_emp)
    return new_emp

# 📡 TASKS ENDPOINTS

@app.get("/api/tasks")
def get_tasks():
    return tasks_db

@app.post("/api/tasks")
def create_task(task: TaskCreate):
    # Generate a unique ID just like crypto.randomUUID() did in React
    new_task = task.dict()
    new_task["id"] = str(uuid.uuid4())
    tasks_db.append(new_task)
    return new_task

@app.put("/api/tasks/{task_id}")
def update_task(task_id: str, task_update: TaskUpdate):
    for task in tasks_db:
        if task["id"] == task_id:
            task["status"] = task_update.status
            return task
    raise HTTPException(status_code=404, detail="Task not found")

@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: str):
    global tasks_db
    initial_length = len(tasks_db)
    tasks_db = [t for t in tasks_db if t["id"] != task_id]
    if len(tasks_db) < initial_length:
        return {"message": "Deleted successfully"}
    raise HTTPException(status_code=404, detail="Task not found")